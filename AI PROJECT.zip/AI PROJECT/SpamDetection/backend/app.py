from flask import Flask, request, jsonify
import pickle
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
import re
import nltk
from nltk.stem.porter import PorterStemmer

# Initialize Flask app
app = Flask(__name__)

# Load the models and vectorizer
with open("RFC.pkl", 'rb') as file:
    model_rfc = pickle.load(file)

with open("DTC.pkl", 'rb') as file:
    model_dtc = pickle.load(file)

with open("MNB.pkl", 'rb') as file:
    model_mnb = pickle.load(file)

with open("count_vectorizer.pkl", 'rb') as file:
    count_vectorizer = pickle.load(file)

# Download stopwords
nltk.download('stopwords')

# Function to preprocess the text
def preprocess_text(text):
    ps = PorterStemmer()
    # Clean the text
    review = re.sub('[^a-zA-Z]', ' ', text)
    review = review.lower()
    review = review.split()
    review = [ps.stem(word) for word in review if word not in nltk.corpus.stopwords.words('english')]
    return ' '.join(review)

@app.route('/')
def home():
    return "Welcome to the Email Spam Detection API!"

@app.route('/predict', methods=['POST'])
def predict():
    # Get the JSON data from the request
    data = request.get_json()
    message = data.get('message', '')

    # Preprocess the input message
    processed_message = preprocess_text(message)
    
    # Transform the message into the CountVectorizer format
    X_input = count_vectorizer.transform([processed_message]).toarray()

    # Make predictions using all models
    pred_rfc = model_rfc.predict(X_input)[0]
    pred_dtc = model_dtc.predict(X_input)[0]
    pred_mnb = model_mnb.predict(X_input)[0]

    # Prepare the response
    response = {
        'message': message,
        'predictions': {
            'Random Forest Classifier': 'Spam' if pred_rfc == 1 else 'Spam',
            'Decision Tree Classifier': 'Spam' if pred_dtc == 1 else 'Ham',
            'Multinomial Naïve Bayes': 'Spam' if pred_mnb == 1 else 'Ham'
        }
    }
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
